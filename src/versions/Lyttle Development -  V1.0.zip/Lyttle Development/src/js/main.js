function mapsLive() {
  if (this.origin !== 'null') {
    document.querySelector('.article--contact-maps').style.display = 'block';
  }
}